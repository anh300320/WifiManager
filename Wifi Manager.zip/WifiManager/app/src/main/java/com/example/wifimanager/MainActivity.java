package com.example.wifimanager;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.InetAddresses;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import Objects.Device;

import static java.sql.Types.NULL;

public class MainActivity extends AppCompatActivity {

    Button btnRead;
    TextView textResult;
    List<Device> devices = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById();

        btnRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                execIpNeighbor();
            }
        });
    }



    public class GetDeviceName extends AsyncTask<Device, Integer, String>{

        @Override
        protected void onProgressUpdate(Integer... values) {

            super.onProgressUpdate(values);
        }

        @Override
        protected String doInBackground(Device... devices) {
            InetAddress inetAddress;

            int i = 0;
            Device device;
            while (i < 300 && (device = devices[i]) != null){
                i++;
                try {
                    inetAddress = InetAddress.getByName(device.getAddress());
                    device.setDeviceName(inetAddress.getHostName());
                    device.show();
                    publishProgress(i);
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }
    }

    public void updateListDevices(){

    }

    public void execIpNeighbor(){
        try {
            devices.clear();

            String str = "ip neigh";
            Process process = Runtime.getRuntime().exec(str);
            BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()));

            String line;
            Device tmp;

            while((line = br.readLine()) != null) {
                tmp = new Device(line);
                if(!tmp.getState().equals("FAILED")){
                    devices.add(tmp);
                    //tmp.show();
                }
            }

            new GetDeviceName().execute(convertListDevice(devices));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    Device[] convertListDevice(List<Device> devices){
        Device[] result = new Device[300];
        int i = 0;
        for(Device device : devices){
            result[i] = device;
            i++;
        }
        return result;
    }

    void findViewById(){
        btnRead = (Button)findViewById(R.id.readclient);
        textResult = (TextView)findViewById(R.id.result);
    }
}